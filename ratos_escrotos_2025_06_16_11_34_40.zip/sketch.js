let scene = 0; // 0: Campo, 1: Cidade, 2: Rato do Campo na Cidade, 3: Rato da Cidade no Campo, 4: Conexão Final



let ratinhoCampoX, ratinhoCampoY;

let ratinhoCidadeX, ratinhoCidadeY;



let lastSceneChangeTime = 0;

const SCENE_DURATION = 8000; // Duração de cada cena em milissegundos (8 segundos)

const TRANSITION_DURATION = 2000; // Duração da transição em milissegundos (2 segundos)



let particleSystem; // Declara o sistema de partículas



function setup() {

  createCanvas(800, 600);

  resetSceneElements();

  particleSystem = new ParticleSystem(); // Inicializa o sistema de partículas

  lastSceneChangeTime = millis();

}



function resetSceneElements() {

  ratinhoCampoX = width * 0.2;

  ratinhoCampoY = height * 0.75;

  ratinhoCidadeX = width * 0.8;

  ratinhoCidadeY = height * 0.79; // Ajustado para a calçada (entre predios e rua)

}



function draw() {

  let currentTime = millis();

  let timeInScene = currentTime - lastSceneChangeTime;



  // Transição de cena automática

  if (timeInScene > SCENE_DURATION + TRANSITION_DURATION) {

    scene = (scene + 1) % 5; // Alterna entre 0, 1, 2, 3, 4

    resetSceneElements(); // Reseta posições e elementos para a nova cena

    lastSceneChangeTime = currentTime;

  }



  // Desenha a cena atual

  if (scene === 0) {

    drawCampoScene();

    // Rato do campo agora é marrom claro

    animateRatinhoIdle(ratinhoCampoX, ratinhoCampoY, color(200, 150, 100)); // Marrom claro

  } else if (scene === 1) {

    drawCidadeScene();

    // Rato da cidade agora é cinza claro

    animateRatinhoIdle(ratinhoCidadeX, ratinhoCidadeY, color(180, 180, 180)); // Cinza claro

  } else if (scene === 2) { // Rato do Campo visita a Cidade

    drawCidadeScene(); // Cena da cidade ao fundo



    // Animação de movimento do rato do campo (marrom claro) para a cidade (esquerda para direita)

    let moveProgress = (timeInScene - TRANSITION_DURATION) / (SCENE_DURATION - TRANSITION_DURATION);

    moveProgress = constrain(moveProgress, 0, 1);



    let currentRatoX = lerp(width * 0.1, width * 0.9, moveProgress);

    let currentRatoY = height * 0.79;



    drawRatinho(currentRatoX, currentRatoY, color(200, 150, 100), 1, frameCount * 0.1); // Rato do campo (marrom claro)

  } else if (scene === 3) { // Rato da Cidade visita o Campo

    drawCampoScene(); // Cena do campo ao fundo



    // Animação de movimento do rato da cidade (cinza claro) para o campo (direita para esquerda)

    let moveProgress = (timeInScene - TRANSITION_DURATION) / (SCENE_DURATION - TRANSITION_DURATION);

    moveProgress = constrain(moveProgress, 0, 1);



    let currentRatoX = lerp(width * 0.9, width * 0.1, moveProgress);

    let currentRatoY = height * 0.75;



    drawRatinho(currentRatoX, currentRatoY, color(180, 180, 180), -1, frameCount * 0.1); // Rato da cidade (cinza claro)

  } else if (scene === 4) {

    drawConexaoScene();

    particleSystem.addParticles(mouseX, mouseY); // Adiciona partículas onde o mouse está

    particleSystem.run(); // Executa o sistema de partículas

    drawConfetti(width / 2, height * 0.4, 30); // Confetes no centro da tela

  }



  // Desenha a transição (overlay)

  if (timeInScene < TRANSITION_DURATION) {

    let inter = map(timeInScene, 0, TRANSITION_DURATION, 0, 1);

    drawTransitionOverlay(inter, true); // Fade out

  } else if (timeInScene > SCENE_DURATION) {

    let inter = map(timeInScene, SCENE_DURATION, SCENE_DURATION + TRANSITION_DURATION, 0, 1);

    drawTransitionOverlay(inter, false); // Fade in

  }

}



// --- Funções de Desenho de Cenas ---



function drawCampoScene() {

  background(173, 216, 230); // Céu azul claro



  // Movimento das nuvens

  let cloudXOffset = (frameCount * 0.3) % (width + 200);



  // Nuvens (normais)

  const cloudPositions = [

    { x: 0.15, y: 0.4, size: 90 }, { x: 0.4, y: 0.18, size: 120 },

    { x: 0.7, y: 0.1, size: 100 }, { x: 0.9, y: 0.25, size: 80 },

    { x: 0.3, y: 0.05, size: 70 }, { x: 0.5, y: 0.3, size: 110 },

    { x: 0.05, y: 0.25, size: 60 }, { x: 0.12, y: 0.33, size: 75 }

  ];

  for (let c of cloudPositions) {

    drawCloud(width * c.x - 200 + cloudXOffset, height * c.y, c.size);

  }



  // Sol

  fill(255, 223, 0); // Amarelo vibrante

  ellipse(width * 0.2, height * 0.2, 80, 80);



  // Detalhe para o sol (efeito de "lens flare" ou brilho)

  for (let i = 0; i < 5; i++) {

    let alpha = map(i, 0, 4, 150, 0);

    fill(255, 255, 0, alpha);

    ellipse(width * 0.2, height * 0.2, 80 + i * 15, 80 + i * 15);

  }



  // Raios de sol

  stroke(255, 223, 0, 150);

  strokeWeight(2);

  let sunCenterX = width * 0.2;

  let sunCenterY = height * 0.2;

  for (let i = 0; i < 12; i++) {

    let angle = map(i, 0, 12, 0, TWO_PI);

    line(sunCenterX + cos(angle) * 45, sunCenterY + sin(angle) * 45,

         sunCenterX + cos(angle) * 60, sunCenterY + sin(angle) * 60);

  }

  noStroke();



  // Grama (verde escuro)

  noStroke();

  fill(85, 107, 47);

  rect(0, height * 0.6, width, height * 0.4);



  // Terra arada (plowed earth)

  fill(101, 67, 33); // Cor de terra arada (marrom escuro)

  rect(0, height * 0.9, width, height * 0.1);



  // --- DETALHES ADICIONAIS CAMPO ---



  // Pássaros voando (mais espaçados e com movimento individual)

  drawBirds(15, (frameCount * 0.8) % (width + 200) - 100, height * 0.1, 0.05);



  // Árvores Variadas

  drawDetailedTree(width * 0.7, height * 0.4, 150, 200, null, true); // Árvore principal com maçãs

  drawDetailedTree(width * 0.1, height * 0.5, 120, 160, color(40, 100, 40), true); // Árvore menor, mais verde, com maçãs

  drawDetailedTree(width * 0.9, height * 0.55, 100, 130, color(60, 120, 60), true); // Outra árvore pequena, com maçãs



  // Arbustos e Pedras

  drawBush(width * 0.3, height * 0.8, 30);

  drawBush(width * 0.5, height * 0.7, 40);

  drawRock(width * 0.05, height * 0.85, 25);

  drawRock(width * 0.75, height * 0.7, 35);

  drawRock(width * 0.4, height * 0.9, 20);



  // Flores estáticas (ajustadas para não ficarem em cima da árvore)

  const flowerPositions = [

    { x: 0.08, y: 0.80, size: 12, color: color(255, 100, 100) },

    { x: 0.15, y: 0.85, size: 10, color: color(150, 255, 150) },

    { x: 0.25, y: 0.75, size: 14, color: color(100, 100, 255) },

    { x: 0.35, y: 0.88, size: 11, color: color(255, 200, 0) },

    { x: 0.45, y: 0.82, size: 13, color: color(200, 0, 200) },

    { x: 0.55, y: 0.70, size: 9, color: color(0, 200, 200) },

    { x: 0.03, y: 0.70, size: 10, color: color(255, 150, 50) },

    { x: 0.1, y: 0.77, size: 13, color: color(50, 255, 150) },

    { x: 0.22, y: 0.68, size: 11, color: color(150, 50, 255) },

    { x: 0.38, y: 0.73, size: 12, color: color(255, 255, 50) },

    { x: 0.5, y: 0.86, size: 10, color: color(255, 50, 150) },

    { x: 0.12, y: 0.90, size: 11, color: color(180, 0, 255) },

    { x: 0.28, y: 0.83, size: 10, color: color(0, 180, 255) },

    { x: 0.42, y: 0.78, size: 13, color: color(255, 0, 180) },

    { x: 0.65, y: 0.80, size: 12, color: color(100, 255, 100) },

    { x: 0.75, y: 0.85, size: 14, color: color(255, 255, 100) },

    { x: 0.88, y: 0.70, size: 11, color: color(50, 150, 255) },

    { x: 0.95, y: 0.75, size: 10, color: color(200, 100, 255) },

    { x: 0.05, y: 0.65, size: 9, color: color(100, 200, 255) },

    { x: 0.18, y: 0.72, size: 12, color: color(255, 50, 50) }

  ];

  for (let f of flowerPositions) {

    drawStaticFlower(width * f.x, height * f.y, f.size, f.color);

  }



  // Toalha de mesa listrada e cesta de piquenique

  let tableclothX = width * 0.7 - 120; // Ajustei para usar a posição da árvore principal

  let tableclothY = height * 0.7;

  let tableclothWidth = 100;

  let tableclothHeight = 70;

  drawCheckeredTablecloth(tableclothX, tableclothY, tableclothWidth, tableclothHeight, color(255, 0, 0), color(255, 255, 255));

  drawPicnicBasket(tableclothX + tableclothWidth / 2, tableclothY + tableclothHeight / 2 + 10, 40);



  // Trator com movimento mais suave: Aparece da direita e vai para a esquerda, virado para a esquerda.

  let tractorX = (width + 100) - ((frameCount * 0.7) % (width + 200)); // Começa fora da tela à direita e se move para a esquerda

  drawTractor(tractorX, height * 0.89, -1); // Direção -1 para ir para a esquerda e virado para a esquerda



  // Celeiro

  drawBarn(width * 0.2, height * 0.5, 150, 100);



  // Cerca

  drawFence(0, height * 0.8, width, 50, 20);

}



function drawCidadeScene() {

  background(40, 50, 70); // Céu noturno escuro



  // Lua no canto direito superior

  drawMoon(width * 0.85, height * 0.15, 60);



  // Nuvens nubladas (adiciona um pouco de variedade)

  const cityClouds = [

    { x: 0.1, y: 0.35, size: 80, color: color(100, 100, 110, 150) },

    { x: 0.3, y: 0.3, size: 100, color: color(90, 90, 100, 150) },

    { x: 0.5, y: 0.4, size: 90, color: color(110, 110, 120, 150) },

    { x: 0.7, y: 0.33, size: 110, color: color(95, 95, 105, 150) },

    { x: 0.85, y: 0.38, size: 70, color: color(105, 105, 115, 150) }

  ];

  for (let c of cityClouds) {

    drawCloud(width * c.x, height * c.y, c.size, c.color);

  }



  // Estrelas

  drawStars(100, height * 0.05);



  // Prédios

  noStroke();

  const buildings = [

    { x: 0.1, y: 0.3, w: 80, h: 0.7, c: color(60, 60, 60) },

    { x: 0.25, y: 0.4, w: 60, h: 0.6, c: color(70, 70, 70) },

    { x: 0.4, y: 0.2, w: 90, h: 0.8, c: color(55, 55, 55) },

    { x: 0.55, y: 0.5, w: 50, h: 0.5, c: color(65, 65, 65) },

    { x: 0.7, y: 0.35, w: 70, h: 0.65, c: color(75, 75, 75) },

    { x: 0.85, y: 0.45, w: 40, h: 0.55, c: color(60, 60, 60) }

  ];

  for (let b of buildings) {

    drawBuilding(width * b.x, height * b.y, b.w, height * b.h, b.c);

  }



  // Calçada

  fill(120, 120, 120);

  rect(0, height * 0.79, width, 10);



  // Rua principal

  fill(80, 80, 80);

  rect(0, height * 0.8, width, height * 0.2);



  // Faixa amarela pontilhada

  let roadMidY = height * 0.9;

  let dashLength = 30;

  let dashGap = 20;

  stroke(255, 200, 0);

  strokeWeight(4);

  for (let x = 0; x < width; x += dashLength + dashGap) {

    line(x, roadMidY, x + dashLength, roadMidY);

  }

  noStroke();



  // --- DETALHES ADICIONAIS CIDADE ---



  // Postes de Luz

  drawStreetLight(width * 0.2, height * 0.78);

  drawStreetLight(width * 0.5, height * 0.78);

  drawStreetLight(width * 0.8, height * 0.78);



  // Sinal de Trânsito

  drawTrafficLight(width * 0.3, height * 0.65, frameCount); // Passa frameCount para animação



  // Carros Detalhados

  let commonCarSpeed = 2;

  let carWidth = 70;

  let minGap = 80;

  let totalCarLength = (carWidth + minGap) * 3;

  let loopLength = width + totalCarLength;



  const carData = [

    { offset: 0, color: color(255, 50, 50), y: 0.85 },

    { offset: (carWidth + minGap), color: color(50, 50, 255), y: 0.9 },

    { offset: (carWidth + minGap) * 2, color: color(50, 200, 50), y: 0.88 }

  ];



  for (let car of carData) {

    let carX = (frameCount * commonCarSpeed + car.offset) % loopLength;

    drawDetailedCar(carX - totalCarLength, height * car.y, car.color);

  }

}



function drawConexaoScene() {

  // Gradiente de fundo que simula a noite

  for (let y = 0; y < height; y++) {

    let inter = map(y, 0, height, 0, 1);

    let c1 = color(10, 20, 40); // Céu noturno bem escuro

    let c2 = color(30, 40, 50); // Horizonte noturno um pouco mais claro

    let mixedColor = lerpColor(c1, c2, inter);

    stroke(mixedColor);

    line(0, y, width, y);

  }



  // Lua no canto direito superior

  drawMoon(width * 0.85, height * 0.15, 60);



  // Adiciona estrelas ao céu noturno da cena final

  drawStars(150);



  // Base grama/rua se misturando (mais escura para a noite)

  noStroke();

  fill(lerpColor(color(40, 50, 20), color(50, 50, 50), 0.5));

  rect(0, height * 0.6, width, height * 0.4);



  // Fogueira entre os ratos

  let campfireX = width * 0.5;

  let campfireY = height * 0.85;

  drawCampfire(campfireX, campfireY, 1.3);



  // Efeito de brilho da fogueira

  let glowRadius = 150;

  let glowAlpha = map(sin(frameCount * 0.05), -1, 1, 50, 100);



  for (let i = 0; i < 3; i++) {

    noStroke();

    fill(255, 150, 0, glowAlpha / (i + 1));

    ellipse(campfireX, campfireY - 20, glowRadius * (1 - i * 0.2), glowRadius * (1 - i * 0.2) * 0.8);

  }



  // Texto festivo

  fill(255);

  textSize(40);

  textAlign(CENTER, CENTER);

  text("Festejando a Conexão!", width / 2, height * 0.2);

  textSize(24);

  text("Campo e Cidade: Juntos!", width / 2, height * 0.3);



  // Ratinhos ajustados para ficarem de frente um para o outro

  let pulse = sin(frameCount * 0.1) * 10;

  // Rato do campo (marrom claro) e rato da cidade (cinza claro)

  let ratCampoColor = color(200, 150, 100); // Marrom claro

  let ratCidadeColor = color(180, 180, 180); // Cinza claro



  drawRatinho(width * 0.4 - pulse, height * 0.75, ratCampoColor, 1, frameCount * 0.1);

  drawRatinho(width * 0.6 + pulse, height * 0.75, ratCidadeColor, -1, frameCount * 0.1);

}



// --- Funções Auxiliares de Desenho e Animação ---



function drawRatinho(x, y, ratColor, direction = 1, animationTime = 0) {

  push();

  translate(x, y);

  scale(direction, 1);



  // Corpo

  fill(ratColor);

  ellipse(0, 0, 40, 30);



  // Orelhas

  fill(ratColor); // Cor da orelha igual ao corpo

  ellipse(-15, -15, 15, 15);

  ellipse(15, -15, 15, 15);



  // Focinho

  fill(60); // Focinho escuro

  ellipse(20, 0, 10, 8);



  // Olhos

  fill(0); // Olhos pretos

  ellipse(10, -5, 5, 5);



  // Patas (animação de "caminhada" aprimorada)

  let legSwing = sin(animationTime * 4) * 5;

  let legLift = abs(sin(animationTime * 4)) * 3;



  fill(ratColor); // Patas da mesma cor do rato

  ellipse(-10 + legSwing, 20 + legLift, 10, 8);

  ellipse(10 - legSwing, 20 + (legLift * 0.5), 10, 8);

  ellipse(-15 - (legSwing * 0.8), 25 + (legLift * 0.7), 10, 8);

  ellipse(15 + (legSwing * 0.8), 25 + (legLift * 0.3), 10, 8);



  // Cauda

  stroke(ratColor); // Cauda da mesma cor do rato

  strokeWeight(2);

  let tailEndX = -20 - 20 + sin(animationTime * 2) * 5;

  let tailEndY = 10 + 10 + cos(animationTime * 2) * 3;

  line(-20, 10, tailEndX, tailEndY);



  pop();

}



function animateRatinhoIdle(x, y, ratColor) {

  let offset = sin(frameCount * 0.05) * 5;

  // Define a direção baseada na nova cor do rato do campo (marrom claro)

  let currentDirection = (ratColor.toString() === color(200, 150, 100).toString()) ? 1 : -1;

  drawRatinho(x, y + offset, ratColor, currentDirection, frameCount * 0.05);

}



function drawCloud(x, y, size, cloudColor = null) {

  noStroke();

  if (cloudColor) {

    fill(cloudColor);

  } else {

    fill(255, 255, 255, 200);

  }

  ellipse(x, y, size * 1.2, size);

  ellipse(x + size * 0.4, y - size * 0.2, size * 0.8, size * 0.8);

  ellipse(x - size * 0.3, y - size * 0.1, size * 0.9, size * 0.9);

}



function drawBuilding(startX, startY, buildingWidth, buildingHeight) {

  fill(80, 80, 80); // Cor base para o prédio

  rect(startX, startY, buildingWidth, buildingHeight);

  drawWindows(startX, startY, buildingWidth, buildingHeight);

}



function drawWindows(startX, startY, buildingWidth, buildingHeight) {

  let windowSize = 12;

  let gap = 8;

  for (let y = startY + gap; y < startY + buildingHeight - gap; y += windowSize + gap) {

    for (let x = startX + gap; x < startX + buildingWidth - gap; x += windowSize + gap) {

      fill(255, 204, 0, random(50, 200)); // Luzes piscando aleatoriamente

      rect(x, y, windowSize, windowSize);

    }

  }

}



function drawDetailedTree(x, y, trunkHeight, foliageSize, foliageColor = null, hasApples = false) {

  push();

  translate(x, y);



  // Tronco

  fill(139, 69, 19);

  rect(-20, 0, 40, trunkHeight);



  // Folhagem

  if (foliageColor) {

    fill(foliageColor);

  } else {

    fill(34, 139, 34); // Verde padrão

  }

  ellipse(0, -trunkHeight + 80, foliageSize, foliageSize * 0.8);

  ellipse(-foliageSize * 0.3, -trunkHeight + 60, foliageSize * 0.6, foliageSize * 0.6);

  ellipse(foliageSize * 0.3, -trunkHeight + 60, foliageSize * 0.6, foliageSize * 0.6);



  // Maçãs Estáticas (se hasApples for true)

  if (hasApples) {

    const applePositions = [

      { x: -25, y: -trunkHeight + 70 }, { x: 15, y: -trunkHeight + 40 },

      { x: 40, y: -trunkHeight + 80 }, { x: -50, y: -trunkHeight + 95 },

      { x: 5, y: -trunkHeight + 105 }, { x: 55, y: -trunkHeight + 90 },

      { x: -35, y: -trunkHeight + 110 }, { x: 25, y: -trunkHeight + 115 },

      { x: -10, y: -trunkHeight + 55 }, { x: 45, y: -trunkHeight + 65 },

      { x: -60, y: -trunkHeight + 85 }, { x: 60, y: -trunkHeight + 75 },

      { x: -20, y: -trunkHeight + 120 }, { x: 30, y: -trunkHeight + 125 },

      { x: -45, y: -trunkHeight + 60 }, { x: 10, y: -trunkHeight + 90 },

      { x: 35, y: -trunkHeight + 50 }, { x: -15, y: -trunkHeight + 100 },

      { x: 0, y: -trunkHeight + 75 }, { x: 50, y: -trunkHeight + 110 },

      { x: -5, y: -trunkHeight + 125 }, { x: 20, y: -trunkHeight + 85 }

    ];



    for (let apple of applePositions) {

      fill(255, 0, 0);

      ellipse(apple.x, apple.y, 10, 10);

      fill(255, 200, 200);

      ellipse(apple.x - 2, apple.y - 2, 3, 3);

      stroke(100, 50, 0);

      strokeWeight(1);

      line(apple.x, apple.y - 5, apple.x, apple.y - 8);

      noStroke();

    }

  }

  pop();

}



// Função para desenhar um trator (virado para a esquerda ou direita)

function drawTractor(x, y, direction = 1) { // direction: 1 para direita, -1 para esquerda

  push();

  translate(x, y);

  scale(direction, 1);



  // Corpo principal

  fill(200, 0, 0); // Vermelho do trator

  rect(0, 0, 80, 40);



  // Cabine

  rect(50, -30, 30, 30);

  fill(150); // Vidro da cabine

  rect(55, -25, 20, 20);



  // Rodas

  fill(50); // Cor das rodas

  ellipse(20, 40, 30, 30); // Roda dianteira (menor)

  ellipse(70, 40, 45, 45); // Roda traseira (maior)



  // Cano de escape

  fill(100);

  rect(45, -50, 5, 20); // Posição ajustada



  pop();

}





function drawDetailedCar(x, y, carColor) {

  push();

  translate(x, y);



  // Base do carro

  fill(carColor);

  rect(0, 0, 70, 30);



  // Teto

  rect(10, -20, 50, 20);



  // Janelas

  fill(150, 200, 255, 180);

  rect(15, -15, 15, 15);

  rect(40, -15, 15, 15);



  // Rodas

  fill(50);

  ellipse(15, 30, 20, 20);

  ellipse(55, 30, 20, 20);



  // Faróis

  if (scene === 1 || scene === 2) {

    fill(255, 255, 100, 200);

    ellipse(68, 5, 5, 5);

    fill(255, 0, 0, 200);

    ellipse(2, 5, 5, 5);

  }



  pop();

}



function drawStars(numStars, minY = 0) {

  for (let i = 0; i < numStars; i++) {

    let x = random(width);

    let y = random(minY, height * 0.5);

    let starSize = random(1, 3);

    let starAlpha = random(100, 255);



    fill(255, 255, 200, starAlpha);

    noStroke();

    ellipse(x, y, starSize, starSize);

  }

}



function drawCampfire(x, y, scaleFactor = 1) {

  push();

  translate(x, y);

  scale(scaleFactor);



  // Troncos

  fill(100, 50, 0);

  rect(-20, 0, 40, 10);

  rotate(PI / 6);

  rect(-20, 0, 40, 10);

  rotate(-PI / 3);

  rect(-20, 0, 40, 10);



  // Chamas

  noStroke();

  let flameHeight = 30 + sin(frameCount * 0.3) * 10;

  let flameWidth = 20 + cos(frameCount * 0.2) * 5;



  fill(255, 200, 0, 200);

  ellipse(0, -flameHeight, flameWidth, flameHeight * 1.5);



  fill(255, 100, 0, 200);

  ellipse(0, -flameHeight * 0.7, flameWidth * 0.8, flameHeight * 1.2);



  fill(255, 0, 0, 150);

  ellipse(0, -flameHeight * 0.4, flameWidth * 0.6, flameHeight * 0.8);



  pop();

}



function drawCheckeredTablecloth(x, y, w, h, color1, color2) {

  push();

  translate(x, y);

  noStroke();

  let squareSize = w / 5;



  for (let row = 0; row < h / squareSize; row++) {

    for (let col = 0; col < w / squareSize; col++) {

      if ((row + col) % 2 === 0) {

        fill(color1);

      } else {

        fill(color2);

      }

      rect(col * squareSize, row * squareSize, squareSize, squareSize);

    }

  }

  pop();

}



function drawPicnicBasket(x, y, size) {

  push();

  translate(x, y);

  noStroke();



  // Corpo da cesta

  fill(139, 69, 19);

  rect(-size / 2, -size / 4, size, size / 2, 5);



  // Tampa da cesta

  fill(160, 82, 45);

  rect(-size / 2 - 2, -size / 4 - 5, size + 4, size / 8, 3);



  // Alça da cesta

  stroke(100, 50, 0);

  strokeWeight(3);

  noFill();

  arc(0, -size / 4 - 5, size * 0.8, size * 0.5, PI, TWO_PI);



  pop();

}



function drawStaticFlower(x, y, size, petalColor) {

  push();

  translate(x, y);

  noStroke();



  // Caule

  fill(50, 150, 50);

  rect(0, 0, 2, size * 0.8);



  // Pétalas

  fill(petalColor);

  ellipse(0, -size * 0.8, size, size * 0.6);

  ellipse(-size * 0.3, -size * 0.6, size * 0.5, size * 0.5);

  ellipse(size * 0.3, -size * 0.6, size * 0.5, size * 0.5);

  ellipse(0, -size * 0.8 - size * 0.3, size * 0.4, size * 0.4);

  ellipse(-size * 0.2, -size * 0.8 + size * 0.2, size * 0.4, size * 0.4);

  ellipse(size * 0.2, -size * 0.8 + size * 0.2, size * 0.4, size * 0.4);



  // Centro da flor

  fill(255, 200, 0);

  ellipse(0, -size * 0.8, size * 0.4, size * 0.4);



  pop();

}



function drawConfetti(centerX, centerY, num) {

  for (let i = 0; i < num; i++) {

    let x = centerX + random(-100, 100) + sin(frameCount * 0.1 + i) * 20;

    let y = centerY + random(-50, 50) + cos(frameCount * 0.08 + i) * 20;

    let size = random(5, 15);

    let angle = random(TWO_PI);

    let confettiColor = color(random(255), random(255), random(255), random(150, 255));



    push();

    translate(x, y);

    rotate(angle + frameCount * 0.1);

    noStroke();

    fill(confettiColor);

    rect(0, 0, size, size);

    pop();

  }

}



// --- Funções de Desenho de Elementos Rurais Adicionais ---



function drawBarn(x, y, h, w) {

  push();

  translate(x, y);

  noStroke();



  // Corpo principal do celeiro

  fill(150, 30, 30); // Vermelho escuro de celeiro

  rect(0, 0, w, h);



  // Telhado

  fill(80, 20, 20); // Marrom escuro para o telhado

  triangle(0, 0, w, 0, w / 2, -h / 2); // Telhado triangular



  // Porta grande no centro

  fill(80, 40, 10); // Marrom para a porta

  rect(w / 2 - 30, h - 80, 60, 80); // Porta maior e mais centralizada



  // Detalhes da porta (dobradiças e maçaneta)

  fill(50); // Cor para dobradiças e maçaneta

  ellipse(w / 2 - 25, h - 40, 5, 5); // Dobradiça esquerda

  ellipse(w / 2 + 25, h - 40, 5, 5); // Dobradiça direita

  rect(w / 2 + 15, h - 50, 5, 10); // Maçaneta



  // Janelas (pequenas e simples, acima da porta)

  fill(200, 200, 200);

  rect(w / 2 - 45, h - 110, 15, 15);

  rect(w / 2 + 30, h - 110, 15, 15);



  // Linhas de madeira no celeiro (opcional)

  stroke(120, 20, 20);

  strokeWeight(1);

  line(w * 0.1, h * 0.3, w * 0.9, h * 0.3);

  line(w * 0.1, h * 0.6, w * 0.9, h * 0.6);

  noStroke();



  pop();

}



function drawFence(x, y, length, height, postGap) {

  push();

  translate(x, y);

  stroke(100, 50, 0); // Marrom para a cerca

  strokeWeight(3);



  // Postes verticais

  for (let i = 0; i < length; i += postGap + 10) {

    line(i, 0, i, height);

  }



  // Tábuas horizontais

  line(0, height * 0.25, length, height * 0.25);

  line(0, height * 0.75, length, height * 0.75);



  noStroke();

  pop();

}



// Novo: Função para desenhar a Lua

function drawMoon(x, y, size) {

  noStroke();

  fill(240, 240, 200); // Cor da lua (um pouco amarelada)

  ellipse(x, y, size, size);



  // Cratera(s) da lua (opcional, para dar mais detalhes)

  fill(200, 200, 170); // Cor mais escura para as crateras

  ellipse(x - size * 0.15, y - size * 0.1, size * 0.2, size * 0.2);

  ellipse(x + size * 0.2, y + size * 0.1, size * 0.15, size * 0.15);

  ellipse(x, y + size * 0.3, size * 0.1, size * 0.1);

}



// --- Funções de Detalhes do Campo ---



function drawBush(x, y, size) {

  noStroke();

  fill(70, 120, 70); // Verde escuro para o arbusto

  ellipse(x, y, size, size * 0.8);

  ellipse(x - size * 0.3, y + size * 0.1, size * 0.6, size * 0.6);

  ellipse(x + size * 0.3, y + size * 0.1, size * 0.6, size * 0.6);

}



function drawRock(x, y, size) {

  noStroke();

  fill(100, 100, 100); // Cinza da pedra

  ellipse(x, y, size, size * 0.7);

  // Sombra sutil

  fill(0, 0, 0, 30);

  ellipse(x + size * 0.1, y + size * 0.2, size * 0.8, size * 0.3);

}



function drawBirds(numBirds, startX, startY, speedFactor) {

  for (let i = 0; i < numBirds; i++) {

    let birdX = (startX + i * 100 + frameCount * speedFactor * (i % 2 === 0 ? 1 : -1)) % (width + 200); // Movimento horizontal individualizado

    if (birdX < -100) birdX += width + 200; // Loop para o outro lado



    let birdY = startY + sin(frameCount * 0.05 + i * 0.5) * 20;



    push();

    translate(birdX, birdY);

    stroke(0);

    strokeWeight(2);

    // Asas

    line(-5, 0, 0, -5);

    line(0, -5, 5, 0);

    noStroke();

    pop();

  }

}



// --- Funções de Detalhes da Cidade ---



function drawStreetLight(x, y) {

  push();

  translate(x, y);



  // Poste

  fill(50);

  rect(-5, -100, 10, 100);



  // Luminária

  fill(80);

  rect(-20, -100, 40, 10);

  fill(255, 255, 100, 200); // Luz

  ellipse(0, -95, 20, 10);

  // Brilho no chão

  noStroke();

  fill(255, 255, 100, 30);

  ellipse(0, 5, 80, 20);



  pop();

}



function drawTrafficLight(x, y, animFrame) {

  push();

  translate(x, y);



  // Poste

  fill(80);

  rect(-5, 0, 10, 80);



  // Caixa do sinal

  fill(20);

  rect(-20, -80, 40, 75, 5);



  // Luzes

  let lightState = floor((animFrame / 60) % 3); // Muda a cada 60 frames (aprox 1 segundo)



  // Vermelho

  fill((lightState === 0) ? 255 : 50, 0, 0);

  ellipse(0, -60, 15, 15);



  // Amarelo

  fill((lightState === 1) ? 255 : 50, (lightState === 1) ? 255 : 50, 0);

  ellipse(0, -35, 15, 15);



  // Verde

  fill(0, (lightState === 2) ? 255 : 50, 0);

  ellipse(0, -10, 15, 15);



  pop();

}



function drawTrashCan(x, y) {

  push();

  translate(x, y);

  noStroke();



  fill(100, 100, 100); // Cinza

  rect(0, 0, 20, 40); // Corpo

  fill(80, 80, 80);

  rect(-2, -5, 24, 5); // Tampa



  pop();

}



function drawBench(x, y) {

  push();

  translate(x, y);

  noStroke();



  fill(139, 69, 19); // Madeira

  rect(0, 0, 50, 10); // Assento

  rect(5, 10, 5, 20); // Perna esquerda

  rect(40, 10, 5, 20); // Perna direita



  pop();

}





// --- Sistema de Partículas para a Conexão ---



class Particle {

  constructor(x, y) {

    this.x = x;

    this.y = y;

    this.vx = random(-1.5, 1.5);

    this.vy = random(-1.5, 1.5);

    this.alpha = 255;

    this.color = color(random(200, 255), random(100, 200), random(0, 100), this.alpha);

    this.size = random(3, 8);

  }



  update() {

    this.x += this.vx;

    this.y += this.vy;

    this.alpha -= 2;

  }



  display() {

    noStroke();

    this.color.setAlpha(this.alpha);

    fill(this.color);

    ellipse(this.x, this.y, this.size, this.size);

  }

}



class ParticleSystem {

  constructor() {

    this.particles = [];

    // Inicializa com algumas partículas para o efeito começar

    for (let i = 0; i < 50; i++) {

      this.particles.push(new Particle(random(width), random(height)));

    }

  }



  addParticles(x, y) {

    // Adiciona partículas continuamente, não apenas com o mouse pressionado

    for (let i = 0; i < 2; i++) { // Adiciona 2 partículas por frame

      this.particles.push(new Particle(x, y));

    }

  }



  run() {

    for (let i = this.particles.length - 1; i >= 0; i--) {

      let p = this.particles[i];

      p.update();

      p.display();

      if (p.alpha < 0) {

        this.particles.splice(i, 1);

      }

    }

    // Garante um número mínimo de partículas ativas

    while (this.particles.length < 100) {

      this.particles.push(new Particle(random(width), random(height)));

    }

  }

}



function drawTransitionOverlay(inter, isFadeOut) {

  noStroke();

  let gradientAlpha = isFadeOut ? map(inter, 0, 1, 255, 0) : map(inter, 0, 1, 0, 255);

  for (let y = 0; y < height; y++) {

    let c = lerpColor(color(0, 0, 0, 0), color(0, 0, 0, gradientAlpha), y / height);

    stroke(c);

    line(0, y, width, y);

  }

}